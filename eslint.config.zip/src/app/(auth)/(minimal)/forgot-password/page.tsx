import { ForgotPasswordForm } from '@/components/auth/forgot-password-form'

export default function ForgotPasswordPage() {
  return (
    <>
      <div className="mb-6 space-y-1">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Mot de passe oublié ?
        </h1>
        <p className="text-sm text-slate-500">
          Indiquez-nous votre adresse email et nous vous enverrons un lien de réinitialisation.
        </p>
      </div>

      <ForgotPasswordForm />
    </>
  )
}