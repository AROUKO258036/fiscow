import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { auth } from '@/lib/auth'
import { VerifyEmailForm } from '@/components/auth/verify-email-form'

export default async function VerifyEmailPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string }>
}) {
  const { token } = await searchParams

  if (token) {
    const record = await prisma.verificationToken.findUnique({ where: { token } })
    if (record && record.expires >= new Date()) {
      await prisma.user.update({
        where: { email: record.email },
        data: { emailVerifiedAt: new Date() },
      })
      await prisma.verificationToken.delete({ where: { id: record.id } })
      redirect('/dashboard')
    }
  }

  const session = await auth()
  if (!session?.user) redirect('/login')

  const user = await prisma.user.findUnique({
    where: { id: Number(session.user.id) },
    select: { emailVerifiedAt: true },
  })

  if (user?.emailVerifiedAt) redirect('/dashboard')

  return <VerifyEmailForm invalid={!!token} />
}
