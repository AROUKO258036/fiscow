import Link from 'next/link'

export default function MinimalAuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen w-full bg-slate-50 flex flex-col items-center justify-center p-4 sm:p-6 lg:p-8">
      {/* Conteneur principal centré */}
      <div className="w-full max-w-md space-y-6">
        
        {/* En-tête Fiscow. centré au milieu */}
        <div className="flex items-center justify-center mb-2 text-center">
          <span className="font-extrabold text-3xl tracking-tight text-slate-900 leading-none">
            Fiscow<span className="text-orange-500">.</span>
          </span>
        </div>

        {/* Card blanche avec ombre douce */}
        <div className="bg-white rounded-2xl p-6 sm:p-8 border border-slate-100 shadow-xl shadow-slate-200/50 relative">
          <Link 
            className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-slate-800 transition-colors mb-6" 
            href="/"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-current" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M19 12H5" />
              <path d="M12 19l-7-7 7-7" />
            </svg>
            Retour à l&rsquo;accueil
          </Link>

          {children}
        </div>
      </div>
    </div>
  )
}