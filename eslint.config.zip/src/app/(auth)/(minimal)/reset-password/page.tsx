import { redirect } from 'next/navigation'
import { prisma } from '@/lib/prisma'
import { ResetPasswordForm } from '@/components/auth/reset-password-form'

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ token?: string }>
}) {
  const { token } = await searchParams

  if (!token) redirect('/forgot-password')

  const record = await prisma.passwordResetToken.findUnique({ where: { token } })
  const valid = record && record.expires >= new Date()

  if (!valid) {
    if (record) await prisma.passwordResetToken.delete({ where: { id: record.id } })
    return (
      <>
        <h1 className="rg-auth__title">Lien invalide ou expiré</h1>
        <p className="rg-auth__subtitle">
          Ce lien de réinitialisation est invalide ou a expiré. Demandez-en un nouveau
          pour continuer.
        </p>
      </>
    )
  }

  return (
    <>
      <h1 className="rg-auth__title">Nouveau mot de passe</h1>
      <p className="rg-auth__subtitle">
        Choisissez un mot de passe solide pour sécuriser votre compte.
      </p>

      <ResetPasswordForm token={token} />
    </>
  )
}
