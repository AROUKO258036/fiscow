import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'
import { ConfirmPasswordForm } from '@/components/auth/confirm-password-form'

export default async function ConfirmPasswordPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string }>
}) {
  const session = await auth()
  if (!session?.user) redirect('/login')

  const { callbackUrl } = await searchParams

  return (
    <>
      <h1 className="rg-auth__title">Zone sécurisée</h1>
      <p className="rg-auth__subtitle">
        Veuillez confirmer votre mot de passe avant de continuer.
      </p>

      <ConfirmPasswordForm callbackUrl={callbackUrl} />
    </>
  )
}
