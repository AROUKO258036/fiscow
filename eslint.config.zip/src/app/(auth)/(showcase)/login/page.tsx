import { LoginForm } from '@/components/auth/login-form'

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string }>
}) {
  const { callbackUrl } = await searchParams

  return (
    <>
      <div className="mb-6 space-y-1">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Connexion
        </h1>
        <p className="text-sm text-slate-500">
          Accédez à votre espace de gestion
        </p>
      </div>

      <LoginForm
        callbackUrl={callbackUrl}
        googleEnabled={!!process.env.AUTH_GOOGLE_ID && !!process.env.AUTH_GOOGLE_SECRET}
      />
    </>
  )
}