import { RegisterForm } from '@/components/auth/register-form'

export default function RegisterPage() {
  return (
    <>
      <div className="mb-6 space-y-1">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">
          Créer votre compte
        </h1>
        <p className="text-sm text-slate-500">
          Configurez votre entreprise et reprenez le contrôle de vos obligations fiscales.
        </p>
      </div>

      <RegisterForm />
    </>
  )
}