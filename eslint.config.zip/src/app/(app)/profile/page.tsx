import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { PageHeader } from '@/components/app/page-header'
import { ProfileInfoForm } from '@/components/app/profile/profile-info-form'
import { PasswordForm } from '@/components/app/profile/password-form'
import { DeleteAccountForm } from '@/components/app/profile/delete-account-form'

export default async function ProfilePage() {
  const session = await auth()
  if (!session?.user) redirect('/login')

  const user = await prisma.user.findUnique({
    where: { id: Number(session.user.id) },
    select: { id: true, name: true, email: true, emailVerifiedAt: true },
  })
  if (!user) redirect('/login')

  return (
    <>
      <PageHeader title="Paramètres" crumbs={[{ label: 'Mon Profil' }]} />

      <div className="row">
        <div className="col-xl-12">
          <div className="card">
            <div className="card-body">
              <div className="border-bottom mb-3 pb-3">
                <h4>Mon Profil</h4>
              </div>

              <ProfileInfoForm name={user.name} email={user.email} emailVerifiedAt={user.emailVerifiedAt} />

              <div className="mt-4 pt-3 border-top">
                <PasswordForm />
              </div>

              <div className="mt-4 pt-3 border-top">
                <DeleteAccountForm />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
