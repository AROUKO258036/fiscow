import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { ensureCalendarEvents, getCalendarEvents } from '@/lib/calendar-service'
import { TermeExplicable } from '@/components/app/terme-explicable'
import { CalendarClient } from './calendar-client'

export const dynamic = 'force-dynamic'

export default async function CalendrierFiscalPage() {
  const session = await auth()
  if (!session?.user) redirect('/login')

  const user = await prisma.user.findUnique({
    where: { id: Number(session.user.id) },
    include: { companies: { orderBy: { createdAt: 'asc' }, take: 1 } },
  })
  const company = user?.companies[0]
  if (!company) redirect('/entreprise/onboarding')

  await ensureCalendarEvents(company.id)
  const currentYear = new Date().getFullYear()
  const events = await getCalendarEvents(company.id, currentYear)

  return (
    <>
      <CalendarClient initialEvents={events} initialYear={currentYear} />

      <div className="d-flex flex-wrap gap-3 mt-3 px-1">
        <span className="d-flex align-items-center gap-1 small">
          <span className="d-inline-block rounded" style={{ width: 12, height: 12, background: '#C8633C' }}></span>{' '}
          <TermeExplicable term="is" text="IS" />
        </span>
        <span className="d-flex align-items-center gap-1 small">
          <span className="d-inline-block rounded" style={{ width: 12, height: 12, background: '#1F5470' }}></span>{' '}
          <TermeExplicable term="tva" text="TVA" />
        </span>
        <span className="d-flex align-items-center gap-1 small">
          <span className="d-inline-block rounded" style={{ width: 12, height: 12, background: '#CC8800' }}></span>{' '}
          <TermeExplicable term="its" text="ITS" />
        </span>
        <span className="d-flex align-items-center gap-1 small">
          <span className="d-inline-block rounded" style={{ width: 12, height: 12, background: '#478558' }}></span>{' '}
          <TermeExplicable term="cnss" text="CNSS" />
        </span>
        <span className="d-flex align-items-center gap-1 small">
          <span className="d-inline-block rounded" style={{ width: 12, height: 12, background: '#823A2A' }}></span>{' '}
          Patente
        </span>
        <span className="d-flex align-items-center gap-1 small">
          <span className="d-inline-block rounded" style={{ width: 12, height: 12, background: '#6DA8C5' }}></span>{' '}
          <TermeExplicable term="tfu" text="TFU" />
        </span>
      </div>
    </>
  )
}
