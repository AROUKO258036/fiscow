'use client'

import { useEffect, useRef, useState } from 'react'
import { TermeExplicable } from '@/components/app/terme-explicable'
import { getEventsAction, markDoneAction } from './actions'

export interface CalendarEventData {
  id: string
  title: string
  start: string
  type: string
  description: string | null
  reference: string | null
  montant_estime: string | null
  statut: string
  precise: boolean | null
  className: string
}

interface CalendarClientProps {
  initialEvents: CalendarEventData[]
  initialYear: number
}

declare global {
  interface Window {
    FullCalendar?: {
      Calendar: new (el: HTMLElement, options: Record<string, unknown>) => {
        render: () => void
        removeAllEvents: () => void
        addEventSource: (source: unknown) => void
      }
    }
  }
}

const TYPE_LABELS: Record<string, string> = {
  is: 'IS',
  tva: 'TVA',
  its: 'ITS',
  cnss: 'CNSS',
  patente: 'Patente',
  tfu: 'TFU',
}

const CALC_ROUTES: Record<string, string> = {
  is: '/calculateurs/is',
  tva: '/calculateurs/tva',
  its: '/calculateurs/its',
  cnss: '/calculateurs/cnss',
  patente: '/calculateurs/patente',
  tfu: '/calculateurs/tfu',
}

function waitForFullCalendar(timeout = 8000): Promise<boolean> {
  return new Promise((resolve) => {
    const start = Date.now()
    const tick = () => {
      if (window.FullCalendar) return resolve(true)
      if (Date.now() - start > timeout) return resolve(false)
      setTimeout(tick, 100)
    }
    tick()
  })
}

interface ClickedEvent {
  id: string
  title: string
  start: Date
  setExtendedProp: (k: string, v: unknown) => void
  extendedProps?: Record<string, unknown>
}

export function CalendarClient({ initialEvents, initialYear }: CalendarClientProps) {
  const calendarElRef = useRef<HTMLDivElement>(null)
  const calendarRef = useRef<{ removeAllEvents: () => void; addEventSource: (s: unknown) => void } | null>(null)
  const currentEventRef = useRef<ClickedEvent | null>(null)
  const [year, setYear] = useState(initialYear)
  const yearRef = useRef(year)

  useEffect(() => {
    yearRef.current = year
  }, [year])

  useEffect(() => {
    let calendar: { render: () => void; removeAllEvents: () => void; addEventSource: (s: unknown) => void } | null = null
    let mounted = true

    waitForFullCalendar().then((ok) => {
      if (!ok || !mounted || !calendarElRef.current || !window.FullCalendar) return
      calendar = new window.FullCalendar.Calendar(calendarElRef.current, {
        initialView: 'dayGridMonth',
        locale: 'fr',
        firstDay: 1,
        height: 'auto',
        headerToolbar: {
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth',
        },
        buttonText: {
          today: "Aujourd'hui",
          month: 'Mois',
        },
        events: initialEvents,
        eventDidMount: (info: { el: HTMLElement; event: { title: string; start: Date } }) => {
          info.el.setAttribute('title', `${info.event.title} — ${info.event.start.toLocaleDateString('fr-FR')}`)
        },
        eventClick: (info: { jsEvent: Event; event: CalendarEventData & { start: Date; setExtendedProp: (k: string, v: unknown) => void } }) => {
          info.jsEvent.preventDefault()
          currentEventRef.current = info.event as unknown as ClickedEvent

          const type = (info.event as unknown as { extendedProps?: { type?: string } }).extendedProps?.type ?? ''
          const label = TYPE_LABELS[type] ?? type.toUpperCase()

          document.getElementById('modal-title')!.textContent = `${label} — ${info.event.title}`
          document.getElementById('modal-date')!.textContent = info.event.start.toLocaleDateString('fr-FR', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
          })
          document.getElementById('modal-montant')!.textContent = (info.event as unknown as { extendedProps?: { montant_estime?: string } }).extendedProps?.montant_estime ?? 'Non configuré'
          document.getElementById('modal-reference')!.textContent = (info.event as unknown as { extendedProps?: { reference?: string } }).extendedProps?.reference ?? '—'
          document.getElementById('modal-description')!.textContent = (info.event as unknown as { extendedProps?: { description?: string } }).extendedProps?.description ?? '—'

          const fiabilite = document.getElementById('modal-fiabilite')!
          const precise = (info.event as unknown as { extendedProps?: { precise?: boolean | null } }).extendedProps?.precise
          if (precise === true) {
            fiabilite.innerHTML = '<span class="rg-fiabilite rg-fiabilite--precis" title="Montant calculé à partir des salaires réels saisis dans votre configuration"><i class="ti ti-circle-check"></i> Salaires réels</span>'
          } else if (precise === false) {
            fiabilite.innerHTML = '<span class="rg-fiabilite rg-fiabilite--estime" title="Estimation à partir de votre chiffre d\'affaires — ajoutez vos salariés pour un calcul précis"><i class="ti ti-alert-triangle"></i> Estimation</span>'
          } else {
            fiabilite.innerHTML = ''
          }

          const statut = (info.event as unknown as { extendedProps?: { statut?: string } }).extendedProps?.statut ?? 'pending'
          const statutBadge = document.getElementById('modal-statut')!
          statutBadge.textContent = statut === 'completed' ? 'Faite' : 'À faire'
          statutBadge.className = statut === 'completed' ? 'badge bg-success' : 'badge bg-warning text-dark'

          const estimerBtn = document.getElementById('btn-estimer') as HTMLAnchorElement
          const calcUrl = CALC_ROUTES[type]
          if (calcUrl) {
            estimerBtn.href = `${calcUrl}?from=calendrier&event_id=${info.event.id}&type=${type}`
            estimerBtn.style.display = ''
          } else {
            estimerBtn.style.display = 'none'
          }

          const modal = document.getElementById('eventModal') as Element
          // @ts-expect-error bootstrap global
          new bootstrap.Modal(modal).show()
        },
      })
      calendar.render()
      calendarRef.current = calendar
    })

    return () => {
      mounted = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const sel = document.getElementById('annee-select') as HTMLSelectElement | null
    if (sel && String(year) !== sel.value) {
      sel.value = String(year)
    }
  }, [year])

  async function handleYearChange(e: React.ChangeEvent<HTMLSelectElement>) {
    const annee = Number(e.target.value)
    setYear(annee)
    const events = await getEventsAction(annee)
    if (calendarRef.current) {
      calendarRef.current.removeAllEvents()
      calendarRef.current.addEventSource(events)
    }
  }

  async function handleMarkDone() {
    const ev = currentEventRef.current
    if (!ev) return
    const btn = document.getElementById('btn-mark-done') as HTMLButtonElement
    if (btn) {
      btn.disabled = true
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span>'
    }
    const result = await markDoneAction(Number(ev.id))
    if (result.success) {
      ev.setExtendedProp('statut', 'completed')
      const badge = document.getElementById('modal-statut')!
      badge.textContent = 'Faite'
      badge.className = 'badge bg-success'
      btn.innerHTML = '<i class="ti ti-check"></i> ✔ Faite'
      setTimeout(() => {
        btn.disabled = false
      }, 1500)
    } else {
      btn.innerHTML = '<i class="ti ti-check"></i> Marquer comme fait'
      setTimeout(() => {
        btn.disabled = false
      }, 1500)
    }
  }

  return (
    <>
      <div className="page-header d-flex align-items-center justify-content-between flex-wrap mb-4">
        <div>
          <h2 className="page-title">Calendrier fiscal</h2>
          <p className="mb-0 text-secondary">
            Suivez vos échéances fiscales — <TermeExplicable term="is" text="IS" />,{' '}
            <TermeExplicable term="tva" text="TVA" />, <TermeExplicable term="its" text="ITS" />,{' '}
            <TermeExplicable term="cnss" text="CNSS" />, Patente,{' '}
            <TermeExplicable term="tfu" text="TFU" />
          </p>
        </div>
        <div className="d-flex gap-2">
          <select id="annee-select" className="form-select" style={{ width: 'auto' }} value={year} onChange={handleYearChange}>
            {[initialYear - 1, initialYear, initialYear + 1, initialYear + 2].map((a) => (
              <option key={a} value={a}>
                {a}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <div id="rg-calendar" ref={calendarElRef}></div>
        </div>
      </div>

      <div className="modal fade" id="eventModal" tabIndex={-1} aria-hidden="true">
        <div className="modal-dialog modal-sm modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="modal-title"></h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
            </div>
            <div className="modal-body">
              <div className="mb-3">
                <label className="text-secondary small text-uppercase">Date</label>
                <p className="fw-medium mb-0" id="modal-date"></p>
              </div>
              <div className="mb-3">
                <label className="text-secondary small text-uppercase">Montant estimé</label>
                <div className="d-flex align-items-center gap-2 flex-wrap">
                  <p className="fw-medium mb-0" id="modal-montant"></p>
                  <span id="modal-fiabilite"></span>
                </div>
              </div>
              <div className="mb-3">
                <label className="text-secondary small text-uppercase">Référence</label>
                <p className="fw-medium mb-0" id="modal-reference"></p>
              </div>
              <div className="mb-0">
                <label className="text-secondary small text-uppercase">Description</label>
                <p className="mb-0" id="modal-description"></p>
              </div>
            </div>
            <div className="modal-footer d-flex justify-content-between">
              <span className="badge" id="modal-statut"></span>
              <div className="d-flex gap-2">
                <a id="btn-estimer" className="btn btn-outline-secondary btn-sm" style={{ display: 'none' }} aria-label="Estimer le montant">
                  <i className="ti ti-calculator"></i> Estimer
                </a>
                <button id="btn-mark-done" className="btn btn-primary btn-sm" aria-label="Marquer comme fait" onClick={() => handleMarkDone()}>
                  <i className="ti ti-check"></i> Marquer comme fait
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
