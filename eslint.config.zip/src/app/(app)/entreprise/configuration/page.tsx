import { redirect } from 'next/navigation'
import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { getApplicableTaxes } from '@/lib/company'
import { PageHeader } from '@/components/app/page-header'
import Link from 'next/link'

const SECTEUR_LABELS: Record<string, string> = {
  commerce: 'Commerce',
  services: 'Services',
  industrie: 'Industrie',
  agriculture: 'Agriculture',
  transport: 'Transport',
  btp: 'BTP / Construction',
  numerique: 'Numérique / Tech',
  autre: 'Autre',
}

// Mappage des badges d'obligations vers des classes Tailwind épurées
const TAX_STYLES: Record<string, { bg: string; text: string; border: string }> = {
  is: { bg: 'bg-orange-50', text: 'text-orange-800', border: 'border-orange-200/60' },
  tva: { bg: 'bg-sky-50', text: 'text-sky-800', border: 'border-sky-200/60' },
  its: { bg: 'bg-amber-50', text: 'text-amber-800', border: 'border-amber-200/60' },
  cnss: { bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-200/60' },
  patente: { bg: 'bg-rose-50', text: 'text-rose-800', border: 'border-rose-200/60' },
  tps: { bg: 'bg-purple-50', text: 'text-purple-800', border: 'border-purple-200/60' },
  tfu: { bg: 'bg-indigo-50', text: 'text-indigo-800', border: 'border-indigo-200/60' },
  iba: { bg: 'bg-slate-100', text: 'text-slate-800', border: 'border-slate-200' },
}

export default async function ConfigurationPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>
}) {
  const session = await auth()
  if (!session?.user) redirect('/login')

  const company = await prisma.company.findFirst({
    where: { userId: Number(session.user.id) },
    include: { employees: { orderBy: { createdAt: 'asc' } } },
  })

  if (!company) redirect('/entreprise/onboarding')

  const { status } = await searchParams

  const taxes = getApplicableTaxes({
    type_entite: company.typeEntite,
    chiffre_affaires: company.chiffreAffaires != null ? Number(company.chiffreAffaires) : null,
    effectif: company.effectif,
    has_property: company.hasProperty,
    regime_tva: company.regimeTva,
  })

  const fmt = new Intl.NumberFormat('fr-FR')
  const actifs = company.employees.filter((e) => e.isActive)

  return (
    <div className="space-y-6 max-w-5xl mx-auto py-4 px-4 sm:px-6">
      <PageHeader title="Configuration" crumbs={[{ label: 'Configuration entreprise' }]} />

      {/* Carte principale */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm p-6 sm:p-8 space-y-8">
        
        {/* En-tête avec action */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <h2 className="text-xl font-bold tracking-tight text-slate-900">
              Configuration entreprise
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              Ces informations permettent de personnaliser vos calculs et déclarations fiscales.
            </p>
          </div>
          <Link
            href="/entreprise/modifier"
            className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-medium text-sm rounded-xl transition-colors shadow-sm self-start sm:self-auto"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-current" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
            </svg>
            Modifier les informations
          </Link>
        </div>

        {/* Message de confirmation */}
        {status === 'entreprise-mise-a-jour' && (
          <div className="p-4 text-sm font-medium text-emerald-800 bg-emerald-50 rounded-xl border border-emerald-200/80 flex items-center gap-2.5">
            <svg viewBox="0 0 24 24" className="w-5 h-5 stroke-current flex-shrink-0 text-emerald-600" fill="none" strokeWidth="2">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" strokeLinecap="round" strokeLinejoin="round"/>
              <polyline points="22 4 12 14.01 9 11.01" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            Entreprise mise à jour avec succès.
          </div>
        )}

        {/* Informations générales / Identité */}
        <div className="space-y-4 pb-6 border-b border-slate-100">
          <h3 className="text-base font-semibold text-slate-900">
            Identité de l’entreprise
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <tbody className="divide-y divide-slate-100">
                <tr>
                  <td className="py-3 text-slate-500 font-medium w-2/5">Raison sociale</td>
                  <td className="py-3 font-semibold text-slate-900">{company.raisonSociale}</td>
                </tr>
                <tr>
                  <td className="py-3 text-slate-500 font-medium">Secteur d’activité</td>
                  <td className="py-3 font-semibold text-slate-900">{SECTEUR_LABELS[company.secteur] ?? company.secteur}</td>
                </tr>
                <tr>
                  <td className="py-3 text-slate-500 font-medium">Type d’entité</td>
                  <td className="py-3 font-semibold text-slate-900">
                    {company.typeEntite === 'societe' ? 'Société (IS)' : 'Entreprise individuelle (IBA)'}
                  </td>
                </tr>
                <tr>
                  <td className="py-3 text-slate-500 font-medium">NIF</td>
                  <td className="py-3 font-semibold text-slate-900">{company.nif}</td>
                </tr>
                <tr>
                  <td className="py-3 text-slate-500 font-medium">RCCM</td>
                  <td className="py-3 font-semibold text-slate-900">{company.rccm ?? 'Non renseigné'}</td>
                </tr>
                <tr>
                  <td className="py-3 text-slate-500 font-medium">Date de création</td>
                  <td className="py-3 font-semibold text-slate-900">
                    {company.dateCreation ? company.dateCreation.toLocaleDateString('fr-FR') : 'Non renseignée'}
                  </td>
                </tr>
                <tr>
                  <td className="py-3 text-slate-500 font-medium">Chiffre d’affaires annuel</td>
                  <td className="py-3 font-semibold text-slate-900">
                    {company.chiffreAffaires != null
                      ? `${fmt.format(Number(company.chiffreAffaires))} FCFA`
                      : 'Non renseigné'}
                  </td>
                </tr>
                <tr>
                  <td className="py-3 text-slate-500 font-medium">Régime TVA</td>
                  <td className="py-3 font-semibold text-slate-900">{company.regimeTva}</td>
                </tr>
                <tr>
                  <td className="py-3 text-slate-500 font-medium">Bien immobilier</td>
                  <td className="py-3 font-semibold text-slate-900">{company.hasProperty ? 'Oui' : 'Non'}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Obligations fiscales détectées */}
        <div className="space-y-4 pb-6 border-b border-slate-100">
          <h3 className="text-base font-semibold text-slate-900">
            Obligations détectées
          </h3>
          <div className="flex flex-wrap gap-2">
            {taxes.map((t) => {
              const style = TAX_STYLES[t.key] ?? { bg: 'bg-slate-100', text: 'text-slate-800', border: 'border-slate-200' }
              return (
                <span
                  key={t.key}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border ${style.bg} ${style.text} ${style.border}`}
                >
                  <strong className="font-semibold">{t.sigle}</strong> — {t.nom}
                </span>
              )
            })}
          </div>
        </div>

        {/* Effectif et Salariés */}
        <div className="space-y-4 pb-6 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <h3 className="text-base font-semibold text-slate-900">
              Employés
            </h3>
            <span className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-full text-xs font-semibold border border-slate-200">
              {actifs.length}
            </span>
          </div>
          <p className="text-xs text-slate-500">
            L’ITS et la CNSS sont calculés sur la base des salaires réels saisis ici.
          </p>

          {actifs.length === 0 ? (
            <p className="text-xs text-slate-400 italic">
              Aucun salarié enregistré.
            </p>
          ) : (
            <div className="max-w-md border border-slate-200/80 rounded-xl overflow-hidden bg-slate-50/50">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200/80 text-xs text-slate-500 font-medium">
                    <th className="py-2.5 px-4 text-left">Poste</th>
                    <th className="py-2.5 px-4 text-end">Salaire brut mensuel</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/60">
                  {actifs.map((e) => (
                    <tr key={e.id}>
                      <td className="py-2.5 px-4 font-medium text-slate-800">{e.poste}</td>
                      <td className="py-2.5 px-4 text-end font-semibold text-slate-900">
                        {fmt.format(Number(e.salaireBrutMensuel))} FCFA
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer / Bouton de retour */}
        <div className="flex items-center justify-end pt-2">
          <Link
            href="/dashboard"
            className="inline-flex items-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium text-sm rounded-xl transition-colors"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-current" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
              <polyline points="9 22 9 12 15 12 15 22" />
            </svg>
            Retour au tableau de bord
          </Link>
        </div>

      </div>
    </div>
  )
}