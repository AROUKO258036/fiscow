'use client'

import { useActionState, useState } from 'react'
import { updateCompanyAction, type UpdateCompanyState } from './actions'

export interface EmployeeInitial {
  id: number
  poste: string
  salaire: string
  is_active: boolean
}

export interface CompanyInitial {
  raison_sociale: string
  nif: string
  rccm: string
  telephone: string
  secteur: string
  type_entite: string
  date_creation: string
  chiffre_affaires: string
  regime_tva: string
  has_property: boolean
  effectif_actif: number
  employees: EmployeeInitial[]
}

const SECTEURS = [
  ['commerce', 'Commerce'],
  ['services', 'Services'],
  ['industrie', 'Industrie'],
  ['agriculture', 'Agriculture'],
  ['transport', 'Transport'],
  ['btp', 'BTP'],
  ['numerique', 'Numérique / Tech'],
  ['autre', 'Autre'],
]

const REGIMES = [
  ['simplifié', 'Simplifié'],
  ['réel', 'Réel'],
  ['transparent', 'Transparent'],
]

const ENTITES = [
  ['societe', 'Société (SARL, SA, SAS, etc.)'],
  ['individuelle', 'Entreprise individuelle'],
]

interface Row {
  key: number
  id: number
  poste: string
  salaire: string
  isActive: boolean
  removed: boolean
}

export function ModifierForm({
  initial,
  postes,
}: {
  initial: CompanyInitial
  postes: string[]
}) {
  const [state, formAction] = useActionState<UpdateCompanyState, FormData>(
    updateCompanyAction,
    {},
  )
  const errors = state.errors ?? {}

  const [rows, setRows] = useState<Row[]>(
    initial.employees.length
      ? initial.employees.map((e) => ({
          key: e.id,
          id: e.id,
          poste: e.poste,
          salaire: e.salaire,
          isActive: e.is_active,
          removed: false,
        }))
      : [{ key: 0, id: 0, poste: '', salaire: '', isActive: true, removed: false }],
  )

  const nextKey = () => Math.max(0, ...rows.map((r) => r.key)) + 1

  const addRow = () =>
    setRows((r) => [...r, { key: nextKey(), id: 0, poste: '', salaire: '', isActive: true, removed: false }])

  const removeRow = (key: number) =>
    setRows((r) => r.map((row) => (row.key === key ? { ...row, removed: true } : row)))

  const updateRow = (key: number, patch: Partial<Row>) =>
    setRows((r) => r.map((row) => (row.key === key ? { ...row, ...patch } : row)))

  const visible = rows.filter((r) => !r.removed)
  const effectif = visible.filter(
    (r) => (r.poste.trim() !== '' || r.salaire.trim() !== '') && r.isActive,
  ).length

  const fieldError = (path: string) => {
    const error = errors[path]
    return error ? (
      <div className="invalid-feedback" style={{ display: 'block' }}>
        {error}
      </div>
    ) : null
  }

  return (
    <div className="row">
      <div className="col-xl-12">
        <div className="card">
          <div className="card-body">
            <div className="border-bottom mb-3 pb-3">
              <h4>Configuration entreprise</h4>
              <p className="text-muted fs-12 mb-0">
                Ces informations permettent de personnaliser vos calculs et déclarations fiscales.
              </p>
            </div>

            <form action={formAction} noValidate>
              <div className="border-bottom mb-3">
                <h6 className="mb-3">Identité de l’entreprise</h6>
                <div className="row">
                  <div className="col-md-6">
                    <div className="row align-items-center mb-3">
                      <div className="col-md-4">
                        <label className="form-label mb-md-0" htmlFor="raison_sociale">
                          Raison sociale <span className="text-danger">*</span>
                        </label>
                      </div>
                      <div className="col-md-8">
                        <input
                          id="raison_sociale"
                          name="raison_sociale"
                          type="text"
                          className={`form-control ${errors.raison_sociale ? 'is-invalid' : ''}`}
                          defaultValue={initial.raison_sociale}
                          required
                        />
                        {fieldError('raison_sociale')}
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="row align-items-center mb-3">
                      <div className="col-md-4">
                        <label className="form-label mb-md-0" htmlFor="secteur">
                          Secteur d’activité <span className="text-danger">*</span>
                        </label>
                      </div>
                      <div className="col-md-8">
                        <select
                          id="secteur"
                          name="secteur"
                          className={`form-control ${errors.secteur ? 'is-invalid' : ''}`}
                          defaultValue={initial.secteur}
                          required
                        >
                          <option value="">Sélectionnez...</option>
                          {SECTEURS.map(([value, label]) => (
                            <option key={value} value={value}>
                              {label}
                            </option>
                          ))}
                        </select>
                        {fieldError('secteur')}
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="row align-items-center mb-3">
                      <div className="col-md-4">
                        <label className="form-label mb-md-0" htmlFor="type_entite">
                          Type d’entité <span className="text-danger">*</span>
                        </label>
                      </div>
                      <div className="col-md-8">
                        <select
                          id="type_entite"
                          name="type_entite"
                          className={`form-control ${errors.type_entite ? 'is-invalid' : ''}`}
                          defaultValue={initial.type_entite}
                          required
                        >
                          {ENTITES.map(([value, label]) => (
                            <option key={value} value={value}>
                              {label}
                            </option>
                          ))}
                        </select>
                        {fieldError('type_entite')}
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="row align-items-center mb-3">
                      <div className="col-md-4">
                        <label className="form-label mb-md-0" htmlFor="telephone">
                          Téléphone
                        </label>
                      </div>
                      <div className="col-md-8">
                        <input
                          id="telephone"
                          name="telephone"
                          type="text"
                          className={`form-control ${errors.telephone ? 'is-invalid' : ''}`}
                          defaultValue={initial.telephone}
                          placeholder="Ex: +229 01 23 45 67"
                        />
                        {fieldError('telephone')}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-bottom mb-3">
                <h6 className="mb-3">Identifiants fiscaux</h6>
                <div className="row">
                  <div className="col-md-6">
                    <div className="row align-items-center mb-3">
                      <div className="col-md-4">
                        <label className="form-label mb-md-0" htmlFor="nif">
                          NIF <span className="text-danger">*</span>
                        </label>
                      </div>
                      <div className="col-md-8">
                        <input
                          id="nif"
                          name="nif"
                          type="text"
                          className={`form-control ${errors.nif ? 'is-invalid' : ''}`}
                          defaultValue={initial.nif}
                          required
                        />
                        {fieldError('nif')}
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="row align-items-center mb-3">
                      <div className="col-md-4">
                        <label className="form-label mb-md-0" htmlFor="rccm">
                          RCCM
                        </label>
                      </div>
                      <div className="col-md-8">
                        <input
                          id="rccm"
                          name="rccm"
                          type="text"
                          className={`form-control ${errors.rccm ? 'is-invalid' : ''}`}
                          defaultValue={initial.rccm}
                        />
                        {fieldError('rccm')}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-bottom mb-3">
                <h6 className="mb-3">Informations financières</h6>
                <div className="row">
                  <div className="col-md-6">
                    <div className="row align-items-center mb-3">
                      <div className="col-md-4">
                        <label className="form-label mb-md-0" htmlFor="date_creation">
                          Date de création
                        </label>
                      </div>
                      <div className="col-md-8">
                        <input
                          id="date_creation"
                          name="date_creation"
                          type="date"
                          className={`form-control ${errors.date_creation ? 'is-invalid' : ''}`}
                          defaultValue={initial.date_creation}
                        />
                        {fieldError('date_creation')}
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="row align-items-center mb-3">
                      <div className="col-md-4">
                        <label className="form-label mb-md-0" htmlFor="chiffre_affaires">
                          Chiffre d’affaires annuel (FCFA)
                        </label>
                      </div>
                      <div className="col-md-8">
                        <input
                          id="chiffre_affaires"
                          name="chiffre_affaires"
                          type="number"
                          step="1"
                          min="0"
                          className={`form-control ${errors.chiffre_affaires ? 'is-invalid' : ''}`}
                          defaultValue={initial.chiffre_affaires}
                        />
                        {fieldError('chiffre_affaires')}
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="row align-items-center mb-3">
                      <div className="col-md-4">
                        <label className="form-label mb-md-0" htmlFor="regime_tva">
                          Régime TVA <span className="text-danger">*</span>
                        </label>
                      </div>
                      <div className="col-md-8">
                        <select
                          id="regime_tva"
                          name="regime_tva"
                          className={`form-control ${errors.regime_tva ? 'is-invalid' : ''}`}
                          defaultValue={initial.regime_tva}
                          required
                        >
                          {REGIMES.map(([value, label]) => (
                            <option key={value} value={value}>
                              {label}
                            </option>
                          ))}
                        </select>
                        {fieldError('regime_tva')}
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="row align-items-center mb-3">
                      <div className="col-md-4">
                        <label className="form-label mb-md-0">Bien immobilier</label>
                      </div>
                      <div className="col-md-8">
                        <div className="d-flex gap-3 pt-1">
                          <label className="me-3" style={{ cursor: 'pointer' }}>
                            <input
                              type="radio"
                              name="has_property"
                              value="1"
                              defaultChecked={initial.has_property}
                            />{' '}
                            Oui
                          </label>
                          <label style={{ cursor: 'pointer' }}>
                            <input
                              type="radio"
                              name="has_property"
                              value="0"
                              defaultChecked={!initial.has_property}
                            />{' '}
                            Non
                          </label>
                        </div>
                        <div style={{ fontSize: '0.75rem', color: 'var(--rg-text-tertiary)' }}>
                          Si oui, la TFU est applicable.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-bottom mb-3">
                <h6 className="mb-3">
                  Employés{' '}
                  <span className="badge" style={{ background: 'var(--rg-accent-brique)' }}>
                    {effectif}
                  </span>
                </h6>
                <p className="text-muted fs-12">
                  L’ITS et la CNSS sont calculés sur la base des salaires réels saisis ici. Choisissez un
                  poste dans la liste selon votre secteur, ou saisissez librement.
                </p>

                <div id="employees-list">
                  {rows.map((row, idx) => (
                    <div
                      key={row.key}
                      className="employee-row d-flex align-items-center gap-2 mb-2"
                      style={row.removed ? { display: 'none' } : undefined}
                    >
                      <input type="hidden" name={`employees[${idx}][id]`} value={row.id} />
                      <input
                        type="hidden"
                        name={`employees[${idx}][to_delete]`}
                        value={row.removed ? '1' : '0'}
                      />
                      <input
                        type="text"
                        name={`employees[${idx}][poste]`}
                        className={`form-control employee-poste ${
                          errors[`employees.${idx}.poste`] ? 'is-invalid' : ''
                        }`}
                        value={row.poste}
                        onChange={(e) => updateRow(row.key, { poste: e.target.value })}
                        list="postes-suggestions"
                        placeholder="Poste"
                      />
                      <input
                        type="number"
                        name={`employees[${idx}][salaire_brut_mensuel]`}
                        className={`form-control employee-salaire ${
                          errors[`employees.${idx}.salaire_brut_mensuel`] ? 'is-invalid' : ''
                        }`}
                        value={row.salaire}
                        onChange={(e) => updateRow(row.key, { salaire: e.target.value })}
                        placeholder="Salaire"
                        min="0"
                        step="1"
                        style={{ width: '180px' }}
                      />
                      <div className="d-flex align-items-center gap-2">
                        <div className="form-check mb-0">
                          <input
                            className="form-check-input employee-active"
                            type="checkbox"
                            name={`employees[${idx}][is_active]`}
                            value="1"
                            id={`emp-active-${row.key}`}
                            checked={row.isActive}
                            onChange={(e) => updateRow(row.key, { isActive: e.target.checked })}
                          />
                          <label
                            className="form-check-label"
                            htmlFor={`emp-active-${row.key}`}
                            style={{ fontSize: '0.75rem' }}
                          >
                            Actif
                          </label>
                        </div>
                        <button
                          type="button"
                          className="btn btn-sm btn-outline-danger employee-remove"
                          title="Retirer"
                          onClick={() => removeRow(row.key)}
                        >
                          <i className="ti ti-trash"></i>
                        </button>
                      </div>
                      {errors[`employees.${idx}.poste`] || errors[`employees.${idx}.salaire_brut_mensuel`] ? (
                        <div
                          className="invalid-feedback"
                          style={{ display: 'block', width: '100%' }}
                        >
                          {errors[`employees.${idx}.poste`] ?? errors[`employees.${idx}.salaire_brut_mensuel`]}
                        </div>
                      ) : null}
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  id="btn-add-employee"
                  className="btn btn-sm btn-outline-light mb-3"
                  onClick={addRow}
                >
                  <i className="ti ti-plus me-1"></i> Ajouter un employé
                </button>

                <div className="mb-3" style={{ fontSize: '0.85rem' }}>
                  <span style={{ color: 'var(--rg-text-secondary)' }}>Effectif déclaré :</span>
                  <span id="effectif-count" className="badge ms-1" style={{ background: 'var(--rg-accent-brique)' }}>
                    {effectif}
                  </span>
                  <span style={{ color: 'var(--rg-text-tertiary)' }}>salarié(s) actif(s)</span>
                </div>

                <datalist id="postes-suggestions">
                  {postes.map((poste) => (
                    <option key={poste} value={poste}></option>
                  ))}
                </datalist>
              </div>

              <div className="d-flex align-items-center justify-content-end gap-3">
                <button type="submit" className="btn btn-primary">
                  Enregistrer
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}
