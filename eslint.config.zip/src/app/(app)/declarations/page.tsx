import { redirect } from 'next/navigation'
import Link from 'next/link'
import { Prisma } from '@prisma/client'
import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { PageHeader } from '@/components/app/page-header'
import { DeclarationFilters } from './declaration-filters'

interface Props {
  searchParams: Promise<Record<string, string | string[] | undefined>>
}

const TAXE_LABELS: Record<string, string> = {
  is: 'IS',
  iba: 'IBA',
  tva: 'TVA',
  its: 'ITS',
  cnss: 'CNSS',
  tps: 'TPS',
  tfu: 'TFU',
  patente: 'Patente',
}

const STATUS_LABELS: Record<string, string> = {
  draft: 'Brouillon',
  filed: 'Déposée',
  paid: 'Payée',
  cancelled: 'Annulée',
}

function fmt(n: number | string | Prisma.Decimal | null): string {
  if (n == null) return '0'
  return Number(n).toLocaleString('fr-FR')
}

function fmtDate(d: Date | null): string {
  if (!d) return '—'
  return d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' })
}

function statutClass(status: string): string {
  switch (status) {
    case 'paid':
      return 'badge bg-success'
    case 'filed':
      return 'badge bg-info'
    case 'draft':
      return 'badge bg-warning text-dark'
    default:
      return 'badge bg-secondary'
  }
}

export default async function DeclarationsIndexPage({ searchParams }: Props) {
  const session = await auth()
  if (!session?.user) redirect('/login')

  const user = await prisma.user.findUnique({
    where: { id: Number(session.user.id) },
    include: { companies: { orderBy: { createdAt: 'asc' }, take: 1 } },
  })
  const company = user?.companies[0]
  if (!company) redirect('/entreprise/onboarding')

  const sp = await searchParams
  const get = (k: string) => {
    const v = sp[k]
    return Array.isArray(v) ? v[0] : v
  }
  const type = get('type')
  const status = get('status')
  const periode = get('periode')
  const page = Math.max(1, Number(get('page')) || 1)
  const perPage = 15

  const where: Record<string, unknown> = { companyId: company.id }
  if (type) where.type = type
  if (status) where.status = status
  if (periode) where.periode = { startsWith: periode }

  const [declarations, totalFiltered] = await Promise.all([
    prisma.declaration.findMany({
      where,
      orderBy: { dueDate: 'desc' },
      skip: (page - 1) * perPage,
      take: perPage,
    }),
    prisma.declaration.count({ where }),
  ])
  const totalPages = Math.max(1, Math.ceil(totalFiltered / perPage))

  const [total, enAttente, payees, montantPaye] = await Promise.all([
    prisma.declaration.count({ where: { companyId: company.id } }),
    prisma.declaration.count({ where: { companyId: company.id, status: { in: ['draft', 'filed'] } } }),
    prisma.declaration.count({ where: { companyId: company.id, status: 'paid' } }),
    prisma.declaration.aggregate({
      where: { companyId: company.id, status: 'paid' },
      _sum: { amountPaid: true },
    }),
  ])

  const hasFilter = Boolean(type || status || periode)

  return (
    <>
      <PageHeader title="Déclarations" crumbs={[{ label: 'Déclarations' }]} />

      <div className="row g-3 mb-3">
        <div className="col-xl-3 col-md-6 d-flex">
          <div className="card flex-fill stat-card-hover">
            <div className="card-body">
              <div className="d-flex align-items-center gap-3">
                <div className="rg-kpi-icon" style={{ background: 'color-mix(in srgb, var(--rg-accent-lagune) 12%, transparent)' }}>
                  <i className="ti ti-file-invoice" style={{ color: 'var(--rg-accent-lagune)' }}></i>
                </div>
                <div>
                  <p className="rg-kpi-label mb-1">Total</p>
                  <h4 className="mb-0">{total}</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-xl-3 col-md-6 d-flex">
          <div className="card flex-fill stat-card-hover">
            <div className="card-body">
              <div className="d-flex align-items-center gap-3">
                <div className="rg-kpi-icon" style={{ background: 'color-mix(in srgb, var(--rg-accent-or) 12%, transparent)' }}>
                  <i className="ti ti-file-alert" style={{ color: 'var(--rg-accent-or)' }}></i>
                </div>
                <div>
                  <p className="rg-kpi-label mb-1">En attente</p>
                  <h4 className="mb-0">{enAttente}</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-xl-3 col-md-6 d-flex">
          <div className="card flex-fill stat-card-hover">
            <div className="card-body">
              <div className="d-flex align-items-center gap-3">
                <div className="rg-kpi-icon" style={{ background: 'color-mix(in srgb, var(--rg-accent-palme) 12%, transparent)' }}>
                  <i className="ti ti-circle-check" style={{ color: 'var(--rg-accent-palme)' }}></i>
                </div>
                <div>
                  <p className="rg-kpi-label mb-1">Payées</p>
                  <h4 className="mb-0">{payees}</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-xl-3 col-md-6 d-flex">
          <div className="card flex-fill stat-card-hover">
            <div className="card-body">
              <div className="d-flex align-items-center gap-3">
                <div className="rg-kpi-icon" style={{ background: 'color-mix(in srgb, var(--rg-accent-brique) 12%, transparent)' }}>
                  <i className="ti ti-coin" style={{ color: 'var(--rg-accent-brique)' }}></i>
                </div>
                <div>
                  <p className="rg-kpi-label mb-1">Total payé</p>
                  <h4 className="mb-0">{fmt(montantPaye._sum.amountPaid)} FCFA</h4>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="card flex-fill">
        <div className="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
          <h5 className="mb-0">Toutes les déclarations</h5>
          <DeclarationFilters
            typeOptions={Object.entries(TAXE_LABELS).map(([value, label]) => ({ value, label }))}
            statusOptions={Object.entries(STATUS_LABELS).map(([value, label]) => ({ value, label }))}
            type={type ?? ''}
            status={status ?? ''}
            periode={periode ?? ''}
          />
          {hasFilter && (
            <Link href="/declarations" className="btn btn-sm btn-outline-secondary">
              Réinitialiser
            </Link>
          )}
        </div>
        <div className="card-body p-0">
          <div className="table-responsive">
            <table className="table table-nowrap mb-0">
              <thead>
                <tr>
                  <th>Type</th>
                  <th>Période</th>
                  <th>Montant dû</th>
                  <th>Montant payé</th>
                  <th>Échéance</th>
                  <th>Statut</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {declarations.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-4 text-muted">
                      <i className="ti ti-file-off" style={{ fontSize: '1.5rem', display: 'block', marginBottom: '0.5rem' }}></i>
                      Aucune déclaration trouvée.
                    </td>
                  </tr>
                ) : (
                  declarations.map((d) => (
                    <tr key={d.id}>
                      <td>
                        <span className={`badge fc-event-${d.type}`} style={{ fontSize: '0.75rem', textTransform: 'uppercase' }}>
                          {TAXE_LABELS[d.type] ?? d.type.toUpperCase()}
                        </span>
                      </td>
                      <td>{d.periode}</td>
                      <td className="rg-montant">{fmt(d.amountDue)} FCFA</td>
                      <td className="rg-montant">{Number(d.amountPaid) > 0 ? `${fmt(d.amountPaid)} FCFA` : '—'}</td>
                      <td>
                        <i className="ti ti-calendar-up me-1" style={{ fontSize: '0.8rem' }}></i>
                        {fmtDate(d.dueDate)}
                      </td>
                      <td>
                        <span className={statutClass(d.status)}>{STATUS_LABELS[d.status] ?? d.status}</span>
                      </td>
                      <td>
                        <div className="action-icon d-inline-flex">
                          <Link href={`/declarations/${d.id}`} className="me-2" title="Voir">
                            <i className="ti ti-eye"></i>
                          </Link>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
        {totalPages > 1 && (
          <div className="card-footer">
            <nav aria-label="Pagination des déclarations">
              <ul className="pagination mb-0 justify-content-end">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => {
                  const params = new URLSearchParams()
                  if (type) params.set('type', type)
                  if (status) params.set('status', status)
                  if (periode) params.set('periode', periode)
                  if (p > 1) params.set('page', String(p))
                  const href = `/declarations${params.toString() ? `?${params.toString()}` : ''}`
                  return (
                    <li className={`page-item${p === page ? ' active' : ''}`} key={p}>
                      <Link className="page-link" href={href}>
                        {p}
                      </Link>
                    </li>
                  )
                })}
              </ul>
            </nav>
          </div>
        )}
      </div>
    </>
  )
}
