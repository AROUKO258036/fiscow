'use client'

interface DeclarationFiltersProps {
  typeOptions: { value: string; label: string }[]
  statusOptions: { value: string; label: string }[]
  type: string
  status: string
  periode: string
}

export function DeclarationFilters({ typeOptions, statusOptions, type, status, periode }: DeclarationFiltersProps) {
  const submit = () => {
    const form = document.getElementById('declaration-filter-form') as HTMLFormElement | null
    form?.submit()
  }

  return (
    <form
      id="declaration-filter-form"
      method="GET"
      action="/declarations"
      className="d-flex align-items-center gap-2 flex-wrap"
    >
      <select
        name="type"
        className="form-select form-select-sm"
        style={{ width: 'auto', minWidth: 100 }}
        defaultValue={type}
        onChange={submit}
      >
        <option value="">Tous les types</option>
        {typeOptions.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      <select
        name="status"
        className="form-select form-select-sm"
        style={{ width: 'auto', minWidth: 120 }}
        defaultValue={status}
        onChange={submit}
      >
        <option value="">Tous les statuts</option>
        {statusOptions.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      <input
        type="text"
        name="periode"
        className="form-control form-control-sm"
        placeholder="Période (ex: 2026-03)"
        defaultValue={periode}
        style={{ width: 'auto', minWidth: 130 }}
      />
      <button type="submit" className="btn btn-sm btn-primary d-inline-flex align-items-center">
        <i className="ti ti-filter me-1"></i>Filtrer
      </button>
    </form>
  )
}
