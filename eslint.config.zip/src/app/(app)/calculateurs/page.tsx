import { redirect } from 'next/navigation'
import Link from 'next/link'
import { auth } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { getApplicableTaxes } from '@/lib/company'
import { PageHeader } from '@/components/app/page-header'
import { TermeExplicable } from '@/components/app/terme-explicable'

const ALL_CALCULATEURS: Record<string, { href: string; icon: string; desc: string; style: string }> = {
  is: { href: '/calculateurs/is', icon: 'ti ti-building-bank', desc: 'Impôt sur les Sociétés (25%-30%)', style: 'brique' },
  tva: { href: '/calculateurs/tva', icon: 'ti ti-arrows-exchange', desc: 'Taxe sur la Valeur Ajoutée (18%)', style: 'lagune' },
  its: { href: '/calculateurs/its', icon: 'ti ti-users', desc: 'Impôt sur les Traitements et Salaires', style: 'laterite' },
  cnss: { href: '/calculateurs/cnss', icon: 'ti ti-shield-check', desc: 'Caisse de Sécurité Sociale (19%)', style: 'palme' },
  tps: { href: '/calculateurs/patente', icon: 'ti ti-certificate', desc: 'Taxe Professionnelle (1,5% du CA)', style: 'bois' },
  tfu: { href: '/calculateurs/tfu', icon: 'ti ti-home', desc: 'Taxe Foncière Unique (5%-6%)', style: 'lagune-light' },
}

const COLORS: Record<string, string> = {
  brique: 'var(--rg-accent-brique)',
  lagune: 'var(--rg-accent-lagune)',
  laterite: 'var(--rg-accent-laterite)',
  palme: 'var(--rg-accent-palme)',
  bois: 'var(--rg-accent-bois)',
  'lagune-light': 'var(--rg-accent-lagune-light)',
}

export default async function CalculateursIndexPage() {
  const session = await auth()
  if (!session?.user) redirect('/login')

  const user = await prisma.user.findUnique({
    where: { id: Number(session.user.id) },
    include: { companies: { orderBy: { createdAt: 'asc' }, take: 1 } },
  })
  if (!user) redirect('/login')
  const company = user.companies[0]
  if (!company) redirect('/entreprise/onboarding')

  const applicableTaxes = getApplicableTaxes({
    type_entite: company.typeEntite,
    chiffre_affaires: company.chiffreAffaires != null ? Number(company.chiffreAffaires) : null,
    effectif: company.effectif,
    has_property: company.hasProperty,
    regime_tva: company.regimeTva,
  })

  const shown = applicableTaxes
    .map((tax) => ({ tax, calc: ALL_CALCULATEURS[tax.key] ?? (tax.key === 'tps' ? ALL_CALCULATEURS.tps : null) }))
    .filter((x): x is { tax: (typeof applicableTaxes)[number]; calc: (typeof ALL_CALCULATEURS)[string] } => !!x.calc)

  return (
    <>
      <PageHeader title="Calculateurs fiscaux" crumbs={[{ label: 'Calculateurs' }]} />

      <div className="row g-4">
        {shown.length === 0 ? (
          <div className="col-12">
            <div className="card">
              <div className="card-body text-center py-5">
                <i className="ti ti-info-circle fs-40 mb-3" style={{ color: 'var(--rg-text-tertiary)' }}></i>
                <p className="mb-0" style={{ color: 'var(--rg-text-secondary)' }}>
                  Aucun calculateur disponible pour le profil de votre entreprise.
                </p>
              </div>
            </div>
          </div>
        ) : (
          shown.map(({ tax, calc }) => (
            <div className="col-xl-4 col-md-6" key={tax.key}>
              <Link href={calc.href} className="card text-decoration-none h-100 calc-card">
                <div className="card-body text-center p-4">
                  <div
                    className="icon-circle mx-auto mb-3"
                    style={{
                      background: `color-mix(in srgb, ${COLORS[calc.style]} 10%, transparent)`,
                      color: COLORS[calc.style],
                    }}
                  >
                    <i className={`${calc.icon} fs-28`}></i>
                  </div>
                  <h5 className="mb-1">
                    <TermeExplicable term={tax.key} text={tax.sigle} />
                  </h5>
                  <p className="text-muted" style={{ fontSize: '0.75rem', marginBottom: 0 }}>
                    {calc.desc}
                  </p>
                </div>
              </Link>
            </div>
          ))
        )}
      </div>
    </>
  )
}
