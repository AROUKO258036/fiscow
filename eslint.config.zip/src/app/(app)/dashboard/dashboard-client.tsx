'use client'

import { useEffect, useRef } from 'react'
import Link from 'next/link'
import { TamponScore } from '@/components/app/tampon-score'
import { DeadlineBanner } from '@/components/app/deadline-banner'
import { KpiCard } from '@/components/app/kpi-card'

interface Deadline {
  obligation: string
  date: string
  montant: string
  joursRestant: number
  estimation: boolean
  salairesPrecis: boolean | null
}

interface RepartitionItem {
  label: string
  montant: string
  classe: string
}

interface DashboardProps {
  score: number
  deadline: Deadline | null
  budgetFiscalRestant: string
  totalImpotsPayes: string
  declarationsEnAttente: number
  repartitionFiscale: RepartitionItem[]
  chart: { categories: string[]; completed: number[]; pending: number[] }
  transactions: {
    id: string
    contribuable: string
    categorie: string
    montant: string
    date: string
    statut: string
    classe_statut: string
  }[]
}

declare global {
  interface Window {
    ApexCharts?: {
      new (el: HTMLElement, options: unknown): {
        render: () => void
        destroy?: () => void
      }
    }
  }
}

function waitForApex(timeout = 8000): Promise<boolean> {
  return new Promise((resolve) => {
    const start = Date.now()
    const tick = () => {
      if (window.ApexCharts) return resolve(true)
      if (Date.now() - start > timeout) return resolve(false)
      setTimeout(tick, 100)
    }
    tick()
  })
}

export function DashboardClient(props: DashboardProps) {
  const {
    score,
    deadline,
    budgetFiscalRestant,
    totalImpotsPayes,
    declarationsEnAttente,
    repartitionFiscale,
    chart,
    transactions,
  } = props

  const chartRef = useRef<{ destroy?: () => void } | null>(null)

  const options = {
    series: [
      { name: 'Faite', data: chart.completed },
      { name: 'À faire', data: chart.pending },
    ],
    colors: ['#478558', '#C8633C'],
    chart: {
      type: 'bar' as const,
      height: 240,
      stacked: true,
      toolbar: { show: false },
      zoom: { enabled: false },
    },
    grid: {
      show: true,
      borderColor: 'var(--rg-border)',
      padding: { top: 5, right: 0 },
      xaxis: { lines: { show: false } },
      yaxis: { lines: { show: true } },
    },
    plotOptions: {
      bar: {
        horizontal: false,
        borderRadius: 6,
        borderRadiusApplication: 'around',
        borderRadiusWhenStacked: 'all',
        columnWidth: '40%',
      },
    },
    dataLabels: { enabled: false },
    yaxis: {
      opposite: true,
      labels: {
        offsetX: -5,
        style: { colors: '#9CA3AF', fontSize: '11px' },
      },
      tickAmount: 6,
    },
    xaxis: {
      categories: chart.categories,
      labels: { style: { colors: '#9CA3AF', fontSize: '11px' } },
    },
    legend: { show: false },
    fill: { opacity: 1 },
  }

  useEffect(() => {
    if (!document.getElementById('headcount-chart')) return
    let cancelled = false
    waitForApex().then((ok) => {
      if (!ok || cancelled) return
      const el = document.querySelector('#headcount-chart')
      if (!el || !window.ApexCharts) return
      // Sous StrictMode (dev) l'effet tourne 2× : détruire le chart précédent
      if (chartRef.current && typeof chartRef.current.destroy === 'function') {
        chartRef.current.destroy()
      }
      const chart = new window.ApexCharts(el as HTMLElement, options)
      chartRef.current = chart
      chart.render()
    })
    return () => {
      cancelled = true
      if (chartRef.current && typeof chartRef.current.destroy === 'function') {
        chartRef.current.destroy()
      }
      chartRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const repartitionColors: Record<string, string> = {
    'border-secondary': 'var(--rg-accent-brique)',
    'border-secondary-800': 'var(--rg-accent-lagune)',
    'border-secondary-700': 'var(--rg-accent-lagune-light)',
    'border-secondary-600': 'var(--rg-accent-palme)',
    'border-secondary-500': 'var(--rg-accent-laterite)',
    'border-secondary-400': 'var(--rg-accent-bois)',
  }

  return (
    <>
      <div className="d-flex align-items-center justify-content-between flex-wrap mb-4">
        <div className="my-auto mb-2">
          <h2>Tableau de bord</h2>
          <nav>
            <ol className="breadcrumb mb-0">
              <li className="breadcrumb-item">
                <Link href="/dashboard">
                  <i className="ti ti-smart-home"></i>
                </Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">
                Dashboard
              </li>
            </ol>
          </nav>
        </div>
        <div className="d-flex my-xl-auto right-content align-items-center flex-wrap gap-3 mb-2">
          <div className="input-icon position-relative">
            <span className="input-icon-addon">
              <i className="ti ti-calendar text-gray-9"></i>
            </span>
            <input type="text" className="form-control date-range bookingrange" placeholder="dd/mm/yyyy - dd/mm/yyyy" style={{ maxWidth: 200 }} />
          </div>
          <button type="button" className="btn btn-primary d-inline-flex align-items-center">
            <i className="ti ti-file-export me-1"></i>Export CSV
          </button>
          <div className="mt-2 head-icons">
            <a href="javascript:void(0);" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-original-title="Collapse" id="collapse-header">
              <i className="ti ti-chevrons-up"></i>
            </a>
          </div>
        </div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-xl-3 col-md-6 d-flex">
          <div className="card flex-fill">
            <div className="card-body d-flex flex-column align-items-center justify-content-center py-4">
              <TamponScore score={score} />
              <p className="mt-3 mb-0 rg-kpi-label">Score de conformité</p>
            </div>
          </div>
        </div>
        <div className="col-xl-9 d-flex">
          <div className="card flex-fill">
            <div className="card-body">
              <div className="d-flex align-items-center justify-content-between mb-3">
                <h5 className="mb-0">Prochaines échéances</h5>
                <a href="#" className="btn btn-outline-light btn-sm">
                  Voir tout
                </a>
              </div>
              {deadline ? (
                <DeadlineBanner
                  obligation={deadline.obligation}
                  date={deadline.date}
                  montant={deadline.montant}
                  joursRestant={deadline.joursRestant}
                  estimation={deadline.estimation}
                  salairesPrecis={deadline.salairesPrecis}
                />
              ) : (
                <p className="text-muted mb-0">Aucune échéance à venir.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-xl-3 col-md-6 d-flex">
          <KpiCard label="Budget fiscal restant" valeur={budgetFiscalRestant} icone="ti ti-report-money" couleur="var(--rg-accent-brique)" />
        </div>
        <div className="col-xl-3 col-md-6 d-flex">
          <KpiCard label="Total Impôts payés" valeur={totalImpotsPayes} icone="ti ti-coin" couleur="var(--rg-accent-lagune)" />
        </div>
        <div className="col-xl-3 col-md-6 d-flex">
          <KpiCard
            label="Déclarations en attente"
            valeur={declarationsEnAttente}
            icone="ti ti-file-alert"
            couleur="var(--rg-accent-or)"
            sousTexte={`${declarationsEnAttente} déclaration(s) à faire`}
          />
        </div>
        <div className="col-xl-3 col-md-6 d-flex">
          <KpiCard
            label="Prochaine échéance"
            valeur={deadline ? `${deadline.joursRestant} jours` : '—'}
            icone="ti ti-calendar-stats"
            couleur="var(--rg-accent-laterite)"
            sousTexte={deadline?.obligation ?? 'Aucune'}
          />
        </div>
      </div>

      <div className="row g-3 mb-3">
        <div className="col-xl-8 d-flex">
          <div className="card flex-fill">
            <div className="card-body pb-0">
              <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
                <h5 className="mb-0">Historique des paiements</h5>
                <div className="rg-chart-legend">
                  <span className="rg-chart-legend-item">
                    <span className="rg-chart-legend-dot" style={{ background: 'var(--rg-accent-brique)' }}></span>
                    Payé
                  </span>
                  <span className="rg-chart-legend-item">
                    <span className="rg-chart-legend-dot" style={{ background: 'var(--rg-border-strong)' }}></span>
                    À payer
                  </span>
                </div>
                <a href="#" className="btn btn-menubar">
                  <i className="ti ti-download"></i>
                </a>
              </div>
              <div id="headcount-chart"></div>
            </div>
          </div>
        </div>
        <div className="col-xl-4 d-flex">
          <div className="card flex-fill">
            <div className="card-body">
              <div className="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
                <h5 className="mb-0">Répartition fiscale</h5>
                <a href="#" className="btn btn-menubar">
                  <i className="ti ti-refresh"></i>
                </a>
              </div>
              <div id="cost-chart"></div>
              <div className="row g-2 mt-3">
                {repartitionFiscale.map((item) => (
                  <div className="col-6 col-sm-4" key={item.label}>
                    <div
                      className="rg-repartition-item"
                      style={{ borderLeftColor: repartitionColors[item.classe] ?? 'var(--rg-accent-brique)' }}
                    >
                      <p>{item.label}</p>
                      <h6>{item.montant}</h6>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="row g-3">
        <div className="col-xl-12">
          <div className="card flex-fill">
            <div className="card-header d-flex align-items-center justify-content-between flex-wrap gap-2">
              <h5 className="mb-0">Dernières transactions</h5>
              <a href="#" className="btn btn-primary btn-sm">
                Voir tout
              </a>
            </div>
            <div className="card-body p-0">
              <div className="table-responsive">
                <table className="table table-nowrap mb-0">
                  <thead>
                    <tr>
                      <th>ID Transaction</th>
                      <th>Contribuable</th>
                      <th>Catégorie</th>
                      <th>Montant</th>
                      <th>Date</th>
                      <th>Statut</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((tx) => (
                        <tr key={tx.id}>
                          <td>
                            <a href="#">{tx.id}</a>
                          </td>
                          <td>{tx.contribuable}</td>
                          <td>{tx.categorie}</td>
                          <td className="rg-montant">{tx.montant}</td>
                          <td>
                            <i className="ti ti-calendar-up me-1" style={{ fontSize: '0.8rem' }}></i>
                            {tx.date}
                          </td>
                          <td>
                            <span className={tx.classe_statut}>{tx.statut}</span>
                          </td>
                          <td>
                            <div className="action-icon d-inline-flex">
                              <a href="#" className="me-2">
                                <i className="ti ti-printer"></i>
                              </a>
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="d-sm-flex align-items-center justify-content-between py-3 mt-3 footer">
        <p>{new Date().getFullYear()} &copy; Regule - Novatrix.</p>
        <p>
          Propulsé par <a href="javascript:void(0);">Novatrix</a>
        </p>
      </div>
    </>
  )
}
