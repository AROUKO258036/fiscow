import { Resend } from 'resend'

type SendEmailParams = {
  to: string
  subject: string
  html: string
}

const BASE_URL = process.env.AUTH_URL || process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

function getResend(): Resend | null {
  const key = process.env.RESEND_API_KEY
  if (!key) return null
  return new Resend(key)
}

export async function sendEmail({ to, subject, html }: SendEmailParams): Promise<void> {
  const resend = getResend()
  const from = process.env.EMAIL_FROM || 'Regule <onboarding@resend.dev>'

  if (!resend) {
    // Fallback dev : parité avec MAIL_MAILER=log de Laravel
    console.log(`[email:dev] to=${to} subject="${subject}"`)
    console.log(html)
    return
  }

  await resend.emails.send({ from, to, subject, html })
}

function layout(body: string): string {
  return `<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
</head>
<body style="margin:0;padding:0;background:#F4F5F7;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#F4F5F7;padding:32px 16px;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(11,31,38,0.08);">
          <tr>
            <td style="background:#0B1F26;padding:24px 32px;">
              <span style="color:#ffffff;font-size:20px;font-weight:700;">Regule</span>
            </td>
          </tr>
          <tr>
            <td style="padding:32px;color:#1A2E36;font-size:15px;line-height:1.6;">
              ${body}
            </td>
          </tr>
          <tr>
            <td style="background:#F8FAFB;padding:16px 32px;color:#6B7A82;font-size:12px;">
              &copy; ${new Date().getFullYear()} Regule — Novatrix. Conformité fiscale au Bénin.
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`
}

function button(text: string, url: string): string {
  return `<p style="text-align:center;margin:32px 0;">
  <a href="${url}" style="background:#0B1F26;color:#ffffff;text-decoration:none;padding:12px 24px;border-radius:8px;font-weight:600;display:inline-block;">${text}</a>
</p>`
}

export async function sendVerificationEmail(to: string, token: string): Promise<void> {
  const url = `${BASE_URL}/verify-email?token=${token}`
  await sendEmail({
    to,
    subject: 'Vérifiez votre adresse email',
    html: layout(`
      <h1 style="margin:0 0 16px;font-size:20px;">Confirmez votre adresse email</h1>
      <p>Bienvenue sur Regule ! Pour activer votre compte, confirmez votre adresse email en cliquant sur le bouton ci-dessous.</p>
      ${button('Vérifier mon email', url)}
      <p style="color:#6B7A82;font-size:13px;">Si le bouton ne fonctionne pas, copiez ce lien :<br />${url}</p>
      <p style="color:#6B7A82;font-size:13px;">Ce lien est valable 24 heures.</p>
    `),
  })
}

export async function sendPasswordResetEmail(to: string, token: string): Promise<void> {
  const url = `${BASE_URL}/reset-password?token=${token}`
  await sendEmail({
    to,
    subject: 'Réinitialisation de votre mot de passe',
    html: layout(`
      <h1 style="margin:0 0 16px;font-size:20px;">Réinitialisez votre mot de passe</h1>
      <p>Nous avons reçu une demande de réinitialisation de mot de passe pour votre compte Regule.</p>
      ${button('Réinitialiser mon mot de passe', url)}
      <p style="color:#6B7A82;font-size:13px;">Si vous n'êtes pas à l'origine de cette demande, ignorez cet email.</p>
      <p style="color:#6B7A82;font-size:13px;">Ce lien est valable 60 minutes.</p>
    `),
  })
}

export async function sendReminderEmail(to: string, companyName: string, events: { title: string; date: string; montant: string }[]): Promise<void> {
  const rows = events
    .map(
      (e) => `
      <tr>
        <td style="padding:10px 0;border-bottom:1px solid #EEF1F4;">${e.title}</td>
        <td style="padding:10px 0;border-bottom:1px solid #EEF1F4;">${e.date}</td>
        <td style="padding:10px 0;border-bottom:1px solid #EEF1F4;text-align:right;">${e.montant}</td>
      </tr>`,
    )
    .join('')

  await sendEmail({
    to,
    subject: `${events.length} échéance${events.length > 1 ? 's' : ''} fiscale${events.length > 1 ? 's' : ''} à venir`,
    html: layout(`
      <h1 style="margin:0 0 16px;font-size:20px;">Bonjour,</h1>
      <p>Voici vos prochaines échéances fiscales pour <strong>${companyName}</strong> :</p>
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:24px 0;">
        ${rows}
      </table>
      <p>Connectez-vous à Regule pour préparer vos déclarations à temps.</p>
      ${button('Accéder à mon calendrier', `${BASE_URL}/calendrier-fiscal`)}
    `),
  })
}
