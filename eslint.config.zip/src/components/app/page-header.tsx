import type { ReactNode } from 'react'
import Link from 'next/link'

interface Crumb {
  label: ReactNode
  href?: string
}

export function PageHeader({ title, crumbs }: { title: ReactNode; crumbs: Crumb[] }) {
  return (
    <div className="d-md-flex d-block align-items-center justify-content-between page-breadcrumb mb-3">
      <div className="my-auto mb-2">
        <h2>{title}</h2>
        <nav>
          <ol className="breadcrumb mb-0">
            <li className="breadcrumb-item">
              <Link href="/dashboard">
                <i className="ti ti-smart-home"></i>
              </Link>
            </li>
            {crumbs.map((c, i) =>
              c.href ? (
                <li className="breadcrumb-item" key={i}>
                  <Link href={c.href}>{c.label}</Link>
                </li>
              ) : (
                <li className="breadcrumb-item active" aria-current="page" key={i}>
                  {c.label}
                </li>
              ),
            )}
          </ol>
        </nav>
      </div>
    </div>
  )
}
