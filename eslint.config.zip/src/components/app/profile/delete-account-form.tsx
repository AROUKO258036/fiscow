'use client'

import { useActionState } from 'react'
import { deleteUserAction, type ProfileState } from '@/app/(app)/profile/actions'

export function DeleteAccountForm() {
  const [state, formAction, pending] = useActionState<ProfileState, FormData>(deleteUserAction, null)

  return (
    <section>
      <h6 className="mb-3 text-danger">Supprimer le compte</h6>
      <p className="text-muted fs-12 mb-3">
        Une fois votre compte supprimé, toutes ses ressources et données seront définitivement effacées.
      </p>

      <button type="button" className="btn btn-danger" data-bs-toggle="modal" data-bs-target="#confirmUserDeletionModal">
        Supprimer mon compte
      </button>

      <div className="modal fade" id="confirmUserDeletionModal" tabIndex={-1} aria-hidden="true">
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <form action={formAction}>
              <div className="modal-header">
                <h5 className="modal-title">Êtes-vous sûr de vouloir supprimer votre compte ?</h5>
                <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div className="modal-body">
                <p className="text-muted fs-12">
                  Une fois votre compte supprimé, toutes ses ressources et données seront définitivement effacées.
                  Veuillez entrer votre mot de passe pour confirmer la suppression.
                </p>
                {state?.error && <div className="text-danger fs-12 mb-2">{state.error}</div>}
                <div className="mb-3">
                  <label className="form-label" htmlFor="delete-password">
                    Mot de passe
                  </label>
                  <input
                    id="delete-password"
                    name="password"
                    type="password"
                    className="form-control"
                    placeholder="Mot de passe"
                    required
                  />
                </div>
              </div>
              <div className="modal-footer">
                <button type="button" className="btn btn-outline-light border" data-bs-dismiss="modal">
                  Annuler
                </button>
                <button type="submit" className="btn btn-danger" disabled={pending}>
                  Supprimer le compte
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
