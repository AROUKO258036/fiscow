'use client'

import { useActionState } from 'react'
import { updatePasswordAction, type ProfileState } from '@/app/(app)/profile/actions'

export function PasswordForm() {
  const [state, formAction, pending] = useActionState<ProfileState, FormData>(updatePasswordAction, null)

  return (
    <section>
      <h6 className="mb-3">Mot de passe</h6>
      <p className="text-muted fs-12 mb-3">
        Assurez-vous d&apos;utiliser un mot de passe long et aléatoire pour rester sécurisé.
      </p>

      <form action={formAction}>
        <div className="row align-items-center mb-3">
          <div className="col-md-2">
            <label className="form-label mb-md-0" htmlFor="update_password_current_password">
              Mot de passe actuel
            </label>
          </div>
          <div className="col-md-10">
            <input
              id="update_password_current_password"
              name="current_password"
              type="password"
              className="form-control"
              autoComplete="current-password"
            />
          </div>
        </div>

        <div className="row align-items-center mb-3">
          <div className="col-md-2">
            <label className="form-label mb-md-0" htmlFor="update_password_password">
              Nouveau mot de passe
            </label>
          </div>
          <div className="col-md-10">
            <input
              id="update_password_password"
              name="password"
              type="password"
              className="form-control"
              autoComplete="new-password"
            />
          </div>
        </div>

        <div className="row align-items-center mb-3">
          <div className="col-md-2">
            <label className="form-label mb-md-0" htmlFor="update_password_password_confirmation">
              Confirmer le mot de passe
            </label>
          </div>
          <div className="col-md-10">
            <input
              id="update_password_password_confirmation"
              name="password_confirmation"
              type="password"
              className="form-control"
              autoComplete="new-password"
            />
          </div>
        </div>

        {state?.error && <div className="text-danger fs-12 mb-3">{state.error}</div>}

        <div className="d-flex align-items-center justify-content-end gap-3">
          <button type="submit" className="btn btn-primary" disabled={pending}>
            Enregistrer
          </button>
          {!pending && state?.success && <span className="text-success fs-12">Enregistré.</span>}
        </div>
      </form>
    </section>
  )
}
