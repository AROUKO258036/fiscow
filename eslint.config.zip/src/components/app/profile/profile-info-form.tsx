'use client'

import { useActionState } from 'react'
import { updateProfileAction, sendVerificationAction, type ProfileState } from '@/app/(app)/profile/actions'

export function ProfileInfoForm({ name, email, emailVerifiedAt }: { name: string; email: string; emailVerifiedAt: Date | null }) {
  const [state, formAction, pending] = useActionState<ProfileState, FormData>(updateProfileAction, null)

  return (
    <section>
      <h6 className="mb-3">Informations du compte</h6>

      <form id="send-verification" action={sendVerificationAction}>
      </form>

      <form action={formAction}>
        <div className="row align-items-center mb-3">
          <div className="col-md-2">
            <label className="form-label mb-md-0" htmlFor="name">
              Nom
            </label>
          </div>
          <div className="col-md-10">
            <input
              id="name"
              name="name"
              type="text"
              className="form-control"
              defaultValue={name}
              required
              autoFocus
              autoComplete="name"
            />
          </div>
        </div>

        <div className="row align-items-center mb-3">
          <div className="col-md-2">
            <label className="form-label mb-md-0" htmlFor="email">
              Email
            </label>
          </div>
          <div className="col-md-10">
            <input
              id="email"
              name="email"
              type="email"
              className="form-control"
              defaultValue={email}
              required
              autoComplete="username"
            />

            {emailVerifiedAt === null && (
              <div className="mt-2">
                <p className="mb-1 text-muted fs-12">
                  Votre adresse email n&apos;est pas vérifiée.{' '}
                  <button type="submit" form="send-verification" className="btn btn-link btn-sm p-0 align-baseline text-primary">
                    Renvoyer l&apos;email de vérification.
                  </button>
                </p>
              </div>
            )}
          </div>
        </div>

        {state?.error && <div className="text-danger fs-12 mb-3">{state.error}</div>}

        <div className="d-flex align-items-center justify-content-end gap-3">
          <button type="submit" className="btn btn-primary" disabled={pending}>
            Enregistrer
          </button>
          {!pending && state?.success && <span className="text-success fs-12">Enregistré.</span>}
        </div>
      </form>
    </section>
  )
}
