'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useState, useEffect } from 'react'
import { TermeExplicable } from '@/components/app/terme-explicable'

function isActive(pathname: string, match: string): boolean {
  if (match === '/dashboard') return pathname === '/dashboard'
  if (match === '/entreprise') {
    return pathname.startsWith('/entreprise/configuration') || pathname.startsWith('/entreprise/onboarding')
  }
  return pathname.startsWith(match)
}

export function AppSidebar({ user }: { user?: { name?: string | null; role?: string | null } }) {
  const pathname = usePathname()
  const [mobileOpen, setMobileOpen] = useState(false)
  const userName = user?.name ?? 'Utilisateur'
  const isAdmin = user?.role === 'ADMIN'

  const calActive = isActive(pathname, '/calendrier-fiscal')
  const declActive = isActive(pathname, '/declarations')
  const entActive = isActive(pathname, '/entreprise')
  const calcOpen = pathname.startsWith('/calculateurs')

  // Fermer le menu mobile lors d'un changement de route
  useEffect(() => {
    setMobileOpen(false)
  }, [pathname])

  return (
    <>
      <div className={`sidebar ${mobileOpen ? 'open' : ''}`} id="sidebar">
        
        {/* LOGO FISCOW */}
        <div className="sidebar-logo px-3 py-3 d-flex align-items-center">
          <Link href="/dashboard" className="d-flex align-items-center gap-2 text-decoration-none">
            
            <span style={{ fontFamily: "'Inter', sans-serif", fontWeight: 800, fontSize: '22px', color: '#171717', lineHeight: 1 }}>
              Fiscow<span style={{ color: '#FF8A1F' }}>.</span>
            </span>
          </Link>
        </div>

        

        {/* MENU SLIMSCROLL */}
        <div className="sidebar-inner slimscroll">
          <div id="sidebar-menu" className="sidebar-menu">
            <ul>
              <li className="menu-title"><span>MENU PRINCIPAL</span></li>

              <li className={pathname === '/dashboard' ? 'active' : ''}>
                <Link href="/dashboard" className={pathname === '/dashboard' ? 'active' : ''}>
                  <i className="ti ti-smart-home"></i>
                  <span>Tableau de bord</span>
                </Link>
              </li>

              <li className={calActive ? 'active' : ''}>
                <Link href="/calendrier-fiscal" className={calActive ? 'active' : ''}>
                  <i className="ti ti-calendar-event"></i>
                  <span>Calendrier fiscal</span>
                </Link>
              </li>

              <li className={`submenu ${calcOpen ? 'active' : ''}`}>
                <Link href="/calculateurs" className={calcOpen ? 'active subdrop' : ''}>
                  <i className="ti ti-calculator"></i>
                  <span>Calculateurs</span>
                  <span className="menu-arrow"></span>
                </Link>
                <ul style={{ display: calcOpen ? 'block' : 'none' }}>
                  <li>
                    <Link href="/calculateurs" className={pathname === '/calculateurs' ? 'active' : ''}>
                      Tous les calculateurs
                    </Link>
                  </li>
                  <li>
                    <Link href="/calculateurs/is" className={pathname === '/calculateurs/is' ? 'active' : ''}>
                      <TermeExplicable term="is" text="IS" /> (Impôt Société)
                    </Link>
                  </li>
                  <li>
                    <Link href="/calculateurs/tva" className={pathname === '/calculateurs/tva' ? 'active' : ''}>
                      <TermeExplicable term="tva" text="TVA" />
                    </Link>
                  </li>
                  <li>
                    <Link href="/calculateurs/its" className={pathname === '/calculateurs/its' ? 'active' : ''}>
                      <TermeExplicable term="its" text="ITS" /> (IRPP)
                    </Link>
                  </li>
                  <li>
                    <Link href="/calculateurs/cnss" className={pathname === '/calculateurs/cnss' ? 'active' : ''}>
                      <TermeExplicable term="cnss" text="CNSS" />
                    </Link>
                  </li>
                </ul>
              </li>

              <li className={declActive ? 'active' : ''}>
                <Link href="/declarations" className={declActive ? 'active' : ''}>
                  <i className="ti ti-file-invoice"></i>
                  <span>Déclarations</span>
                </Link>
              </li>

              <li className={entActive ? 'active' : ''}>
                <Link href="/entreprise/configuration" className={entActive ? 'active' : ''}>
                  <i className="ti ti-building"></i>
                  <span>Configuration entreprise</span>
                </Link>
              </li>

              <li className={pathname === '/profile' ? 'active' : ''}>
                <Link href="/profile" className={pathname === '/profile' ? 'active' : ''}>
                  <i className="ti ti-settings"></i>
                  <span>Paramètres</span>
                </Link>
              </li>

              {isAdmin && (
                <>
                  <li className="menu-title"><span>ADMINISTRATION</span></li>
                  <li className={pathname.startsWith('/admin') ? 'active' : ''}>
                    <Link href="/admin" className={pathname.startsWith('/admin') ? 'active' : ''}>
                      <i className="ti ti-shield-lock"></i>
                      <span>Administration</span>
                    </Link>
                  </li>
                </>
              )}
            </ul>
          </div>
        </div>
      </div>

      {mobileOpen && (
        <div className="sidebar-overlay" onClick={() => setMobileOpen(false)} />
      )}
    </>
  )
}