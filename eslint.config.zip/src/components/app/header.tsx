'use client'

import Link from 'next/link'
import { useEffect, useState } from 'react'
import { logoutAction } from '@/app/(auth)/actions'
import {
  NotificationDropdown,
  type NotificationItem,
} from './notification-dropdown'

export function AppHeader({
  user,
  notifications,
}: {
  user: {
    name: string
    email: string
    role?: string | null
  }
  notifications: NotificationItem[]
}) {
  const [mini, setMini] = useState(false)
  const [slideNav, setSlideNav] = useState(false)

  useEffect(() => {
    document.body.classList.toggle('mini-sidebar', mini)

    return () => {
      document.body.classList.remove('mini-sidebar')
    }
  }, [mini])

  useEffect(() => {
    const wrapper = document.querySelector('.main-wrapper')

    wrapper?.classList.toggle('slide-nav', slideNav)
    document.documentElement.classList.toggle('menu-opened', slideNav)

    return () => {
      wrapper?.classList.remove('slide-nav')
      document.documentElement.classList.remove('menu-opened')
    }
  }, [slideNav])

  const initial =
    user.name?.trim().charAt(0).toUpperCase() || 'U'

  return (
    <header className="header fiscow-app-header">
      <div className="main-header fiscow-header-inner">

        {/* DESKTOP LOGO */}
        <div className="fiscow-header-brand">
          <Link
            href="/dashboard"
            className="fiscow-header-logo"
          >
            Fiscow<span>.</span>
          </Link>
        </div>

        {/* DESKTOP ACTIONS */}
        <div className="fiscow-header-user">
          <div className="fiscow-header-actions">

            {/* THEME */}
            <button
              type="button"
              className="fiscow-header-icon-btn"
              id="rg-theme-toggle"
              title="Changer le thème"
              aria-label="Changer le thème"
            >
              <i
                className="ti ti-sun"
                id="rg-theme-icon"
              />
            </button>

            {/* NOTIFICATIONS */}
            <div className="fiscow-header-notifications">
              <NotificationDropdown
                items={notifications}
              />
            </div>

            {/* PROFILE */}
            <div className="dropdown profile-dropdown">
              <button
                type="button"
                className="fiscow-profile-trigger"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                <span className="fiscow-profile-avatar">
                  {initial}
                </span>

                <span className="fiscow-profile-copy">
                  <span className="fiscow-profile-name">
                    {user.name}
                  </span>

                  <span className="fiscow-profile-role">
                    {user.role === 'ADMIN'
                      ? 'Administrateur'
                      : 'Utilisateur'}
                  </span>
                </span>

                <i className="ti ti-chevron-down fiscow-profile-chevron" />
              </button>

              <div className="dropdown-menu dropdown-menu-end fiscow-profile-menu">

                <div className="fiscow-profile-menu-head">
                  <div className="fiscow-profile-avatar fiscow-profile-avatar-lg">
                    {initial}
                  </div>

                  <div className="fiscow-profile-menu-identity">
                    <strong>{user.name}</strong>
                    <span>{user.email}</span>
                  </div>
                </div>

                <div className="fiscow-profile-menu-body">
                  <Link
                    className="fiscow-profile-menu-item"
                    href="/profile"
                  >
                    <i className="ti ti-user-circle" />
                    <span>Mon Profil</span>
                  </Link>

                  <Link
                    className="fiscow-profile-menu-item"
                    href="/dashboard"
                  >
                    <i className="ti ti-settings" />
                    <span>Paramètres</span>
                  </Link>

                  {user.role === 'ADMIN' && (
                    <Link
                      className="fiscow-profile-menu-item"
                      href="/admin"
                    >
                      <i className="ti ti-shield-lock" />
                      <span>Administration</span>
                    </Link>
                  )}
                </div>

                <div className="fiscow-profile-menu-footer">
                  <form action={logoutAction}>
                    <button
                      type="submit"
                      className="fiscow-profile-menu-item fiscow-profile-logout"
                    >
                      <i className="ti ti-logout" />
                      <span>Déconnexion</span>
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* MOBILE HEADER */}
        <div className="fiscow-mobile-header">

          <button
            id="mobile_btn"
            type="button"
            className="fiscow-mobile-menu-btn"
            aria-label={
              slideNav
                ? 'Fermer le menu'
                : 'Ouvrir le menu'
            }
            aria-expanded={slideNav}
            onClick={() =>
              setSlideNav((value) => !value)
            }
          >
            <span className="fiscow-menu-lines">
              <span />
              <span />
              <span />
            </span>
          </button>

          <Link
            href="/dashboard"
            className="fiscow-mobile-logo"
          >
            Fiscow<span>.</span>
          </Link>

          <div className="dropdown fiscow-mobile-user-menu">
            <button
              type="button"
              className="fiscow-mobile-actions-btn"
              data-bs-toggle="dropdown"
              aria-expanded="false"
              aria-label="Menu utilisateur"
            >
              <i className="ti ti-dots-vertical" />
            </button>

            <div className="dropdown-menu dropdown-menu-end fiscow-profile-menu">

              <div className="fiscow-mobile-profile-head">
                <div className="fiscow-profile-avatar">
                  {initial}
                </div>

                <div>
                  <strong>{user.name}</strong>
                  <span>{user.email}</span>
                </div>
              </div>

              <Link
                className="fiscow-profile-menu-item"
                href="/profile"
              >
                <i className="ti ti-user-circle" />
                <span>Mon Profil</span>
              </Link>

              <button
                type="button"
                className="fiscow-profile-menu-item"
                id="rg-theme-toggle-mobile"
              >
                <i
                  className="ti ti-sun"
                  id="rg-theme-icon-mobile"
                />

                <span id="rg-theme-label-mobile">
                  Mode clair
                </span>
              </button>

              {user.role === 'ADMIN' && (
                <Link
                  className="fiscow-profile-menu-item"
                  href="/admin"
                >
                  <i className="ti ti-shield-lock" />
                  <span>Administration</span>
                </Link>
              )}

              <div className="fiscow-mobile-menu-separator" />

              <form action={logoutAction}>
                <button
                  type="submit"
                  className="fiscow-profile-menu-item fiscow-profile-logout"
                >
                  <i className="ti ti-logout" />
                  <span>Déconnexion</span>
                </button>
              </form>
            </div>
          </div>
        </div>

      </div>

      {slideNav && (
        <div
          className="sidebar-overlay"
          onClick={() => setSlideNav(false)}
        />
      )}
    </header>
  )
}