import type { ReactNode } from 'react'
import { submitDeclaration } from '@/app/(app)/calculateurs/actions'

interface CalculatorShellProps {
  titre: string
  soustitre?: string
  type: 'is' | 'tva' | 'its' | 'cnss' | 'patente' | 'tfu'
  montant: number | null
  eventId?: string | null
  form: ReactNode
  resultats: ReactNode
}

export function CalculatorShell({
  titre,
  soustitre = '',
  type,
  montant,
  eventId,
  form,
  resultats,
}: CalculatorShellProps) {
  return (
    <div className="card">
      <div className="card-body">
        <div className="mb-4 pb-3" style={{ borderBottom: '1px solid var(--rg-border)' }}>
          <h3>{titre}</h3>
          {soustitre && (
            <p style={{ fontSize: '0.8125rem', color: 'var(--rg-text-secondary)', marginBottom: 0 }}>{soustitre}</p>
          )}
        </div>
        <div className="row g-4">
          <div className="col-lg-5">{form}</div>
          <div className="col-lg-7">{resultats}</div>
        </div>

        {montant != null && montant !== 0 && (
          <div className="mt-4" style={{ borderTop: '1px solid var(--rg-border)', paddingTop: '1.5rem' }}>
            <form action={submitDeclaration.bind(null, type, String(montant), eventId ?? undefined)}>
              <div className="d-flex align-items-center gap-2">
                <span style={{ fontSize: '0.875rem', color: 'var(--rg-text-secondary)' }}>
                  <i className="ti ti-file-check"></i> Montant estimé :{' '}
                  <strong>{montant.toLocaleString('fr-FR')} FCFA</strong>
                </span>
                <button type="submit" className="btn btn-success btn-sm ms-auto">
                  <i className="ti ti-file-plus"></i> Soumettre la déclaration
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  )
}
