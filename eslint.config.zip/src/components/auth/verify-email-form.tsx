'use client'

import { resendVerificationAction, logoutAction, type AuthState } from '@/app/(auth)/actions'
import { useActionState, useTransition } from 'react'

export function VerifyEmailForm({ invalid }: { invalid: boolean }) {
  const [state, formAction, pending] = useActionState<AuthState, FormData>(resendVerificationAction, null)
  const [logoutPending, startLogout] = useTransition()

  return (
    <>
      <h1 className="rg-auth__title">Vérifiez votre adresse email</h1>
      <p className="rg-auth__subtitle">
        Avant de commencer, veuillez vérifier votre adresse email en cliquant
        sur le lien que nous venons de vous envoyer.
      </p>

      {invalid && !state?.success && (
        <div className="rg-auth__error">
          Ce lien de vérification est invalide ou a expiré. Cliquez ci-dessous pour en recevoir un nouveau.
        </div>
      )}
      {state?.success && <div className="rg-auth__success">{state.success}</div>}
      {state?.error && <div className="rg-auth__error">{state.error}</div>}

      <div className="rg-auth__row" style={{ justifyContent: 'flex-start', marginTop: 8 }}>
        <form action={formAction}>
          <button type="submit" className="rg-auth__btn" style={{ width: 'auto' }} disabled={pending}>
            {pending ? 'Envoi…' : "Renvoyer l'email de vérification"}
          </button>
        </form>
      </div>

      <div className="rg-auth__footer">
        <button
          type="button"
          disabled={logoutPending}
          onClick={() => startLogout(async () => {
            await logoutAction()
          })}
          className="rg-auth__link"
          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, padding: 0 }}
        >
          Se déconnecter
        </button>
      </div>
    </>
  )
}
