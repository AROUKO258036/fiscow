'use client'

import { resetPasswordAction, type AuthState } from '@/app/(auth)/actions'
import { useActionState } from 'react'
import Link from 'next/link'
import { PasswordField } from '@/components/auth/password-field'

export function ResetPasswordForm({ token }: { token: string }) {
  const [state, formAction, pending] = useActionState<AuthState, FormData>(resetPasswordAction, null)
  const values = state?.values ?? {}

  return (
    <form action={formAction}>
      {state?.error && <div className="rg-auth__error">{state.error}</div>}

      <input type="hidden" name="token" value={token} />

      <div className="rg-auth__field">
        <label htmlFor="email" className="rg-auth__label">
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          className="rg-auth__input"
          autoComplete="username"
          required
          autoFocus
          placeholder="vous@exemple.com"
          defaultValue={values.email ?? ''}
        />
      </div>

      <div className="rg-auth__field">
        <label htmlFor="password" className="rg-auth__label">
          Nouveau mot de passe
        </label>
        <PasswordField
          id="password"
          name="password"
          autoComplete="new-password"
          placeholder="••••••••"
        />
      </div>

      <div className="rg-auth__field">
        <label htmlFor="password_confirmation" className="rg-auth__label">
          Confirmer le mot de passe
        </label>
        <PasswordField
          id="password_confirmation"
          name="password_confirmation"
          autoComplete="new-password"
          placeholder="••••••••"
        />
      </div>

      <button type="submit" className="rg-auth__btn" disabled={pending}>
        {pending ? 'Réinitialisation…' : 'Réinitialiser le mot de passe'}
      </button>

      <div className="rg-auth__footer">
        <Link className="rg-auth__link" href="/login">
          Retour à la connexion
        </Link>
      </div>
    </form>
  )
}
