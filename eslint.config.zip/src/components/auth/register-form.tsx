'use client'

import { registerAction, type AuthState } from '@/app/(auth)/actions'
import { useActionState } from 'react'
import Link from 'next/link'
import { PasswordField } from '@/components/auth/password-field'

export function RegisterForm() {
  const [state, formAction, pending] = useActionState<AuthState, FormData>(registerAction, null)
  const values = state?.values ?? {}

  return (
    <>
      {state?.error && (
        <div className="p-3 mb-5 text-sm font-medium text-red-600 bg-red-50 rounded-xl border border-red-200">
          {state.error}
        </div>
      )}

      <form action={formAction} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-slate-700 mb-1.5">
            Nom complet
          </label>
          <input
            id="name"
            name="name"
            type="text"
            className="w-full px-3.5 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all text-sm"
            autoComplete="name"
            required
            placeholder="Votre nom"
            defaultValue={values.name ?? ''}
          />
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1.5">
            Email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            className="w-full px-3.5 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all text-sm"
            autoComplete="username"
            required
            placeholder="vous@exemple.com"
            defaultValue={values.email ?? ''}
          />
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-slate-700 mb-1.5">
            Mot de passe
          </label>
          <PasswordField
            id="password"
            name="password"
            autoComplete="new-password"
            placeholder="••••••••"
          />
        </div>

        <div>
          <label htmlFor="password_confirmation" className="block text-sm font-medium text-slate-700 mb-1.5">
            Confirmer le mot de passe
          </label>
          <PasswordField
            id="password_confirmation"
            name="password_confirmation"
            autoComplete="new-password"
            placeholder="••••••••"
          />
        </div>

        <button
          type="submit"
          className="w-full py-3 px-4 bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white font-semibold rounded-xl shadow-sm hover:shadow transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed mt-2 text-sm"
          disabled={pending}
        >
          {pending ? 'Création…' : 'Créer mon compte'}
        </button>

        <div className="text-center text-sm text-slate-500 mt-6 pt-2">
          Déjà inscrit ?{' '}
          <Link className="text-orange-600 hover:text-orange-700 font-medium transition-colors" href="/login">
            Se connecter
          </Link>
        </div>
      </form>
    </>
  )
}