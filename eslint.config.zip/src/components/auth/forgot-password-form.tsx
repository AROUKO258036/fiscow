'use client'

import { forgotPasswordAction, type AuthState } from '@/app/(auth)/actions'
import { useActionState } from 'react'
import Link from 'next/link'

export function ForgotPasswordForm() {
  const [state, formAction, pending] = useActionState<AuthState, FormData>(forgotPasswordAction, null)
  const values = state?.values ?? {}

  return (
    <form action={formAction} className="space-y-4">
      {/* Message d'erreur */}
      {state?.error && (
        <div className="p-3 text-sm font-medium text-red-600 bg-red-50 rounded-xl border border-red-200">
          {state.error}
        </div>
      )}

      {/* Message de succès */}
      {state?.success && (
        <div className="p-3 text-sm font-medium text-emerald-700 bg-emerald-50 rounded-xl border border-emerald-200">
          {state.success}
        </div>
      )}

      <div>
        <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-1.5">
          Email
        </label>
        <input
          id="email"
          name="email"
          type="email"
          className="w-full px-3.5 py-2.5 bg-slate-50/50 border border-slate-200 rounded-xl text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition-all text-sm"
          autoComplete="username"
          required
          placeholder="vous@exemple.com"
          defaultValue={values.email ?? ''}
        />
      </div>

      <button
        type="submit"
        className="w-full py-3 px-4 bg-orange-500 hover:bg-orange-600 active:bg-orange-700 text-white font-semibold rounded-xl shadow-sm hover:shadow transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed mt-2 text-sm"
        disabled={pending}
      >
        {pending ? 'Envoi…' : 'Envoyer le lien de réinitialisation'}
      </button>

      <div className="text-center text-sm text-slate-500 mt-6 pt-2">
        <Link className="text-orange-600 hover:text-orange-700 font-medium transition-colors inline-flex items-center gap-1.5" href="/login">
          <svg viewBox="0 0 24 24" className="w-4 h-4 stroke-current" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 12H5" />
            <path d="M12 19l-7-7 7-7" />
          </svg>
          Retour à la connexion
        </Link>
      </div>
    </form>
  )
}