'use client'

import { confirmPasswordAction, type AuthState } from '@/app/(auth)/actions'
import { useActionState } from 'react'
import { PasswordField } from '@/components/auth/password-field'

export function ConfirmPasswordForm({ callbackUrl }: { callbackUrl?: string }) {
  const [state, formAction, pending] = useActionState<AuthState, FormData>(confirmPasswordAction, null)

  return (
    <form action={formAction}>
      {state?.error && <div className="rg-auth__error">{state.error}</div>}

      {callbackUrl ? <input type="hidden" name="callbackUrl" value={callbackUrl} /> : null}

      <div className="rg-auth__field">
        <label htmlFor="password" className="rg-auth__label">
          Mot de passe
        </label>
        <PasswordField
          id="password"
          name="password"
          autoComplete="current-password"
          placeholder="••••••••"
        />
      </div>

      <button type="submit" className="rg-auth__btn" disabled={pending}>
        {pending ? 'Vérification…' : 'Confirmer'}
      </button>
    </form>
  )
}
